<?php

use yii\helpers\Html;
use yii\bootstrap4\ActiveForm;

/**
 * @var yii\web\View                 $this
 * @var dektrium\user\models\User    $user
 * @var dektrium\user\models\Profile $profile
 * @var dektrium\user\Module         $module
 */

$this->title = Yii::t('user', 'Login Infrormation');
$this->params['breadcrumbs'][] = ['label' => Yii::t('user', 'Users'), 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>

<?= $this->render('/_alert', [
    'module' => Yii::$app->getModule('user'),
]) ?>

<?php $form = ActiveForm::begin([
    'enableAjaxValidation'   => false,
    'enableClientValidation' => false
]); ?>

<div class="card mb-3">
    <div class="card-header bg-info">
        <?= Html::encode($this->title) ?>
    </div>
    <div class="card-body">
        <?= $this->render('_user', ['form' => $form, 'user' => $user]) ?>
    </div>
</div>

<div class="card mb-3">
<div class="card-header bg-info">
        <?= Yii::t('user', 'User Profile') ?>
    </div>
    <div class="card-body">
        <?= $this->render('_profile', ['form' => $form, 'profile' => $profile]) ?>
    </div>
</div>

<p>
    <?= Html::submitButton(Yii::t('user', 'Save'), ['class' => 'btn btn-primary btn-sm']) ?>
    <?php if (!$user->getIsConfirmed()): ?>
        <?= Html::a(Yii::t('user', 'Confirm'), ['confirm', 'id' => $user->id, 'back' => 'update'], ['class' => 'btn btn-success btn-sm', 'data-method' => 'post']) ?>
    <?php endif; ?>
    <?php if ($user->getIsBlocked()): ?>
        <?= Html::a(Yii::t('user', 'Unblock'), ['block', 'id' => $user->id, 'back' => 'update'], ['class' => 'btn btn-success btn-sm', 'data-method' => 'post', 'data-confirm' => Yii::t('user', 'Are you sure you want to unblock this user?')]) ?>
    <?php else: ?>
        <?= Html::a(Yii::t('user', 'Block'), ['block', 'id' => $user->id, 'back' => 'update'], ['class' => 'btn btn-danger btn-sm', 'data-method' => 'post', 'data-confirm' => Yii::t('user', 'Are you sure you want to block this user?')]) ?>
    <?php endif; ?>
</p>

<?php ActiveForm::end(); ?>
